package com.imcs.starter;

import com.imcs.Tester.CustomerTester;

public class Starter {

	public static void main(String[] args) {
		//creating the instance of customerTester
		CustomerTester customerTester=new CustomerTester();
		//displaying the menu
		customerTester.customerMenu();
		}
}
