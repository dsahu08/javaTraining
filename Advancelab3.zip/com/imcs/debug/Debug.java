package com.imcs.debug;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import com.imcs.customer.Customer;
import com.imcs.savingsAccount.SavingsAccount;

public class Debug {
	
	public static void main(String []args){
		
		Customer customer=new Customer(1001,"Tan"); 
		SavingsAccount sb1=new SavingsAccount(9001,customer,2000,5,1000);
		
		//Serializing the above object
		FileOutputStream fileOutputStream = new FileOutputStream("data.ser");
		ObjectOutputStream objStream = new	ObjectOutputStream(fileOutputStream);
				objStream.close();
				objStream.writeObject(sb1);
				
				
				//deserializing the Savings Account object
				FileInputStream fileInput=new FileInputStream("data.ser"); 
				BufferedInputStream bufferedStream=new BufferedInputStream(fileInput);
				SavingsAccount deserializedSb=(SavingsAccount)bufferedStream.read();
	}

}
