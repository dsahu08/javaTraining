package com.Wells;

import day1.Assignment6Account;
import day1.Assignment4Customer;
import transaction.DepositTransaction;
import transaction.WithdrawTransaction;

public class WellsBank {
	
	public static void main(String[] args) {
		Assignment4Customer firstCustomer=new Assignment4Customer(1001,"Raj");
		
		Assignment6Account firstAccount=new Assignment6Account(2001,firstCustomer,20000);
		
		Assignment4Customer secondCustomer=new Assignment4Customer(1002,"Narayan");
		
		Assignment6Account secondAccount=new Assignment6Account(2001,secondCustomer,20000);
		
		DepositTransaction firstDeposit=new DepositTransaction(9001, secondAccount, 5001, 4000);
		
		firstDeposit.start();
		
		DepositTransaction secondDeposit=new DepositTransaction(9002, firstAccount, 5002, 7000);
		
		secondDeposit.start();
		
		WithdrawTransaction secondWithdrawTransaction=new WithdrawTransaction(9004,firstAccount, secondCustomer,500);
		
		Thread secondWithdraw=new Thread(secondWithdrawTransaction);
		secondWithdraw.start();
		
		WithdrawTransaction firstWithdrawTransaction=new WithdrawTransaction(9003,firstAccount, firstCustomer, 500);
				Thread firstWithdrawal=new Thread(firstWithdrawTransaction);
				
				firstWithdrawal.start();
	}

}
