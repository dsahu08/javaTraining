package general;

import fund.BankFund;
import transaction.LoanTransaction;

public class WellsBank {
	
	public static void main(String [] args) {
		
		BankFund WellsBankFund=new BankFund(9000000);
		
		LoanTransaction[] loanTransactions=new LoanTransaction[100];
		
		for(int index=0;index<loanTransactions.length;index++){
			loanTransactions[index]=new LoanTransaction(WellsBankFund, (1000+index),250000);
		}
		
		for(int index=0;index<loanTransactions.length;index++){
			loanTransactions[index].run();
			}
	}

}
