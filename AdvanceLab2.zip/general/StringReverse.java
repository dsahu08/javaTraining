package general;

public class StringReverse {

/*	public static void main(String[] args) {
	
		String name = "Dharmendra";
		
		String reverse = "";
		
		for(int i=0; i<name.length();i++) {
			reverse = reverse + name.charAt((name.length()-1)-i);
		}
		
		System.out.println(reverse);

	}
*/
}
