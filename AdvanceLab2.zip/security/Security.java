package security;

import day1.Assignment6Account;
import day1.Assignment4Customer;
import exception.UnAuthorizedWithdrawTransactionException;

public class Security {
	
	public void authorization(Assignment6Account account, Assignment4Customer customer) 
			throws UnAuthorizedWithdrawTransactionException {
	
		if(account.getCustomer().getCustomerId()!=customer.getCustomerId()) {
			 throw new UnAuthorizedWithdrawTransactionException();
		}
	}

}
