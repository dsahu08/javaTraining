package day1;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class Assignment1 {

	public void printCustomers(List<String> arrayList) {
		
		Iterator<String> iterator = arrayList.iterator();
		System.out.println("Customers are: ");
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("Jack");
		list.add("Harry");
		list.add("Tabrej");
		list.add("Leezu");
		Assignment1 addCustomer = new Assignment1();
		addCustomer.printCustomers(list);
	}

}
