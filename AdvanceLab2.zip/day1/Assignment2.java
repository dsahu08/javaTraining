package day1;

import java.util.Set;
import java.util.HashSet;
public class Assignment2 {

	public void printSetRecord(Set<String> set) {
		if(set.isEmpty()) {
			System.out.println("Set is an empty set");
		}
		else {
			System.out.println("Set elements are :"+set);
		}
	}
	
	public static void main(String[] args) {
	Set<String> set = new HashSet<String>();
	set.add("First Entry");
	set.add("Second Entry");
	set.add("Third Entry");
	set.add("First Entry");
	Assignment2 setDemo = new Assignment2();
	setDemo.printSetRecord(set);
	Set<String> emptySet = new HashSet<String>();
	setDemo.printSetRecord(emptySet);

	}

}
