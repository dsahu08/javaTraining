package day1;

import day1.Assignment4Customer;

public class Assignment6Account {
	
	private int accountNo;
	
	private Assignment4Customer customer;
	
	protected double balance;
	
	public Assignment6Account(int accountNo, Assignment4Customer customer, double balance) {
		
		this.accountNo = accountNo;
		this.balance = balance;
		this.customer = customer;
	}
	
	public Assignment6Account() {
		
	}
	
	public int getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setbalance(double balance) {
		this.balance = balance;
	}
	
	public Assignment4Customer getCustomer() {
		return customer;
	}
	
	public void setCustomer(Assignment4Customer customer) {
		this.customer = customer;
	}

}
