package day1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import day1.Assignment4Customer;

public class CustomerDB {
	
	private List<Assignment4Customer> customerList = new ArrayList<Assignment4Customer>();
	
	public boolean saveCustomer(Assignment4Customer customer) {
		boolean status = false;
		
		status = customerList.add(customer);
		
		return status;
	}
	
	public List<Assignment4Customer> getAllCustomers(){
		return customerList;
	}
	
	public Set<Integer> getLoanAvailedCustomer(){
		
		Set<Integer> loanAvailedCustomers = new TreeSet<Integer>();
		
		Iterator<Assignment4Customer> customerIterator = customerList.iterator();
		while(customerIterator.hasNext()) {
			Assignment4Customer customer = customerIterator.next();
			
			if(customer.isLoanAvailed()) {
				loanAvailedCustomers.add(customer.getCustomerId());
			}
		}
		return loanAvailedCustomers;
	}

}
