package day1;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import day1.CustomerDB;
import day1.Assignment4Customer;
import day1.Login;

public class WellsBank {

	public static final CustomerDB customerDB = new CustomerDB();
	
	private static final Login login = new Login();
	
	public static void main(String[] args) {
		
		Assignment4Customer cust1 = new Assignment4Customer(1001,"Tan",false);
		customerDB.saveCustomer(cust1);
		login.addLogin(1001, "Wells123");
		
		Assignment4Customer cust2 = new Assignment4Customer(1002,"John",true);
		customerDB.saveCustomer(cust2);
		login.addLogin(1002, "Wells123");
		
		Assignment4Customer cust3 = new Assignment4Customer(1003,"Sam",true);
		customerDB.saveCustomer(cust3);
		login.addLogin(1001, "Wells123");
		
		Assignment4Customer cust4 = new Assignment4Customer(1004,"Raj",false);
		customerDB.saveCustomer(cust4);
		login.addLogin(1001, "Wells123");
		
		List<Assignment4Customer> customerList = customerDB.getAllCustomers();
		if(customerList.isEmpty()) {
			System.out.println("NO customer in the Bank");
		}else {
			printCustomerList(customerList);
		}
		
		Set<Integer> loanAvailedCustomers = customerDB.getLoanAvailedCustomer();
		System.out.println("\nCustomers who have Availed the loan");
		System.out.println("--------------------------------------");
		for(int custId:loanAvailedCustomers) {
			System.out.println(custId);
		}

	}
	
	public static void printCustomerList(List<Assignment4Customer> customerList){
		Iterator<Assignment4Customer> custIterator = customerList.iterator();
		System.out.println("			Customer Detials");
		System.out.println("----------------------------"+
											"--------------");
		System.out.println("cust Id\tcustomer Name\tLoan Avialed");
		
		while
			(custIterator.hasNext()) {
			Assignment4Customer customer= custIterator.next();
			System.out.print(customer.getCustomerId()+"\t");
			System.out.print(customer.getCustomerName()+"\t\t");
			
			String displayString = "NO";
			if(customer.isLoanAvailed()) {
				displayString = "Yes";
			}
			
			System.out.println(displayString);
		}
	}

}
