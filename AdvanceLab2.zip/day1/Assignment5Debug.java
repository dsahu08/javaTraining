package day1;

public class Assignment5Debug {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
