package transaction;

import day1.Assignment6Account;
import day1.Assignment4Customer;
import exception.InsufficientBalanceException;
import exception.UnAuthorizedWithdrawTransactionException;
import security.Security;

public class WithdrawTransaction extends Security implements Runnable{

	private int transactionId;
	private Assignment6Account account;
	private Assignment4Customer customer;
	private double amount;
	
	public WithdrawTransaction(int transactionId, Assignment6Account account,Assignment4Customer customer,double amount){
		this.transactionId=transactionId;
		this.account=account;
		this.customer=customer;
		this.amount=amount;
	}
	
	public double withdraw(Assignment6Account account,double amount) throws InsufficientBalanceException
	{
	
		if(account.getBalance()>=amount){
			account.setbalance(account.getBalance()-amount);
		}
		else{
			throw new InsufficientBalanceException();
		}
		return account.getBalance();
	}
	
	public void run() {
		try{
		
		authorization(account, customer);
		
		double balance=withdraw(account, amount);
		
		System.out.println(transactionId+" transaction"+"completed!!! and the balance amount is "+balance);
		}
		catch(UnAuthorizedWithdrawTransactionException unAuthorizedWithdrawTransactionException){
		
			System.out.println(transactionId+" transaction "+"failed!!! and "+unAuthorizedWithdrawTransactionException.getMessage());
		}
		catch(InsufficientBalanceException insufficientBalanceException){
		//display the error message for insufficient balance
		System.out.println(transactionId+" transaction "+"failed!!! and your account has insufficient"+"balance");
		}
		}
}
