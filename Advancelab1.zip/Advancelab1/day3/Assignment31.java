package day3;

import java.util.*;
public class Assignment31 {
	public static void main(String[] args){
		ArrayList employeeId = new ArrayList();
		employeeId.add(1001);
		employeeId.add(1002);
		employeeId.add("1003");
		for(int count=0; count<employeeId.size();count++){
			
		}
		
	}
}
