package day3;

import java.lang.reflect.*;
public class Assignment32 {

	public static void main(String[] args) {
		try{
			Class classobj = Class.forName("Employee");
	
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}
}
