package day3;

 class StringMock{
	String capacity;
	public StringMock(){
		
	}
	public StringMock(String capacity){
		this.capacity = capacity;
	}
	
	@Deprecated
	
	public static int search(String string, char searchItem){
		int index;
		char [] charArray = string.toCharArray();
		
		for(index =0; index<charArray.length;index++){
			if(charArray[index]==searchItem)
				return index;
		}
	}
}

public class Assignment33 {

	public static void main(String[] args){
		String message = "What's in the name";
		StringMock stringMock = new StringMock();
		stringMock.search("abc",'a');
	}
}
