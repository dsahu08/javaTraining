package day2;

public class Assignment23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name=null;
		int total = 100, count =0;
		try{
			int average = total/count;
			System.out.println(average);
			System.out.println(name.length());
		}
		catch(ArithmeticException exception){
			System.out.println("Arithmetic Exception "+exception.getMessage());
		}
		catch(NullPointerException exception){
			System.out.println("object is null");
		}
		System.out.println("Conitinuing the execution...");
	}

}
