package day2;
class Customer{
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int pincode;
	
	Customer(){
		
	}
	Customer(int customerId, String customerName, String customerAddress, int pincode){
		
	}
	
	void setCustomerId(int customerId){
		
	}
	
	int getCustomerId()
	{
		return 0;
	}
	void setCustomerName(String customerName){
		
	}
	
	String getCustomerName(){
		return "";
	}
	
	
	
}
public class Assignment13Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
