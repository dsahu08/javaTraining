package day2;

public class Assignment21b {
	
	String garbageLocation;
	Assignment21b garbage;

	public static void main(String[] args) {
		Assignment21b garbage1 = new Assignment21b();
		garbage1.garbage = new Assignment21b();
		garbage1.garbageLocation="Dallas";
		garbage1.garbage.garbageLocation="Hootagalli";
		garbage1.garbage.garbage = garbage1;
		garbage1.garbage.garbage=null;
		garbage1.garbage=null;
		garbage1 = null;
	}

}


