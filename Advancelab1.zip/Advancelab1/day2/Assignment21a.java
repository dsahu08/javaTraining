package day2;

class Wheels{
	
}

public class Assignment21a {
String vehicleName;
Wheels [] wheels = new Wheels[4];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment21a vehicle = new Assignment21a();
	}

}
