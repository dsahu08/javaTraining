package day2;

public interface petAnimal{
	
}

public class Animal{
	
}

public class Hippo extends Animal{
	
}

public class Dog extends Animal implements PetAnimal{
	
}

public class Cat extends Animal implements PetAnimal{
	
}

public class Assignment18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
