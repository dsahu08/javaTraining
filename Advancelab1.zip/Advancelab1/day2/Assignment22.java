package day2;

import java.util.*;

class Employee{
	int empId;
	//Employee(int empId, String fName){
	//	this.empId = empId;	
	//}
}
public class Assignment22 {

	
	public static void main(String[] args) {
		Vector empList = new Vector();
		int empNo = 1000;
		Employee emp = new Employee();
		for(int count=0;count<5;count++){
			emp.empId = empNo;
			empNo++;
			empList.add(emp);
		}
		
	}

}
