package day2;
class Tyre{
	
}
public class Assignment21Car {
	Tyre tyre;
	String name;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment21Car carMain = new Assignment21Car();
		carMain.setFeatures(carMain);
	}
	void setFeatures(Assignment21Car car){
		tyre = new Tyre();
		car.setName("Swift");
	}
	
	void setName(String name){
		this.name = name;
	}

}
