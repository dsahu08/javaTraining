package day2;
class Assignment14Customer{
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int pincode;
	
	public Assignment14Customer(){
		System.out.println("Customer default constructor");
	}
	public Assignment14Customer(int customerId, String customerName, String customerAddress, int pincode){
		System.out.println("Customer parameterized constructor");
	}
	
	public void setCustomerId(int customerId){
		this.customerId = customerId;
	}
	
	public int getCustomerId(){
		return customerId;
	}
	
	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}
	public String getCustomerName(){
		return customerName;
	}
	public void setCustomerAddress(String customerAddress){
		this.customerAddress = customerAddress;
	}
	public String getCustomerAddress(){
		return customerAddress;
	}
	
	public void setPincode(int pincode){
		this.pincode = pincode;
	}
}

class Account {
	private int accountNo;
	private Assignment14Customer customer;
	protected double balance;
	
	Account(){
		System.out.println("Account default constructor");
	}
	Account(int accountNo,Assignment14Customer customer, double balance ){
		System.out.println("Account parameterized constructor");
	}
	
	public Assignment14Customer getCustomer(){
		return customer;
	}
	public double balanceEnquiry(){
		return balance;
	}
	public void deposit(double amount){
		this.balance = balance+amount;
	}
	
}

class SavingAccount extends Account{
	private double minimumBalance = 500.00;
	private int interestRate=12;
	
	public SavingAccount(){
		
		
	}
	public SavingAccount(int accountNo, Assignment14Customer customer, double balance){
		
	}
	Account account = new Account();
	public void withdraw(double amount){
		if(account.balance>=500){
			if(amount<=account.balance){
				account.balance = account.balance - amount;	
			}
			else{
				System.out.println("Withdraw Amount is greater than the balance, try some less amount");
			}
		}
		else{
			System.out.println("Account balance is less than the minimum balance");
		}
		
	}
	
	public void calculateInterest(){
		double interest;
		interest = (account.balance*12)/100;
		account.balance = account.balance+interest;
	}
	
}

class CurrentAccount extends Account{
	private double currentAmount;
	
	CurrentAccount(){
		
	}
	public CurrentAccount(int accountNo, Assignment14Customer customer, double balance, double currentAmoount){
	Account account = new Account(accountNo,customer,balance);
	}
	public void withdraw(double amount){
		
	}
	
	public double getEligibilityAmount(){
		return 0;
	}
	
}

public class Assignment14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account = new Account();
		
	}

}
