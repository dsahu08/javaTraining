package day2;
class Assignment16Customer{
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int pincode;
	
	public Assignment16Customer(){
		System.out.println("Customer default constructor");
	}
	public Assignment16Customer(int customerId, String customerName, String customerAddress, int pincode){
		System.out.println("Customer parameterized constructor");
	}
	
	public void setCustomerId(int customerId){
		this.customerId = customerId;
	}
	
	public int getCustomerId(){
		return customerId;
	}
	
	public void setCustomerName(String customerName){
		this.customerName = customerName;
	}
	public String getCustomerName(){
		return customerName;
	}
	public void setCustomerAddress(String customerAddress){
		this.customerAddress = customerAddress;
	}
	public String getCustomerAddress(){
		return customerAddress;
	}
	
	public void setPincode(int pincode){
		this.pincode = pincode;
	}
}

abstract class Assignment16Account {
	private int accountNo;
	private Assignment16Customer customer;
	protected double balance;
	
	Assignment16Account(){
		System.out.println("Account default constructor");
	}
	Assignment16Account(int accountNo,Assignment16Customer customer, double balance ){
		System.out.println("Account parameterized constructor");
	}
	
	public Assignment16Customer getCustomer(){
		return customer;
	}
	public double balanceEnquiry(){
		return balance;
	}
	public void deposit(double amount){
		this.balance = balance+amount;
	}
	
}

class Assignment16SavingAccount extends Account{
	private double minimumBalance = 500.00;
	private int interestRate=12;
	
	public Assignment16SavingAccount(){
		
		
	}
	public Assignment16SavingAccount(int accountNo, Assignment16Customer customer, double balance){
		
	}
	Account account = new Account();
	public void withdraw(double amount){
		if(account.balance>=500){
			if(amount<=account.balance){
				account.balance = account.balance - amount;	
			}
			else{
				System.out.println("Withdraw Amount is greater than the balance, try some less amount");
			}
		}
		else{
			System.out.println("Account balance is less than the minimum balance");
		}
		
	}
	
	public void calculateInterest(){
		double interest;
		interest = (account.balance*12)/100;
		account.balance = account.balance+interest;
	}
	
}

class Assignment16CurrentAccount extends Account{
	private double currentAmount;
	
	Assignment16CurrentAccount(){
		
	}
	public Assignment16CurrentAccount(int accountNo, Assignment14Customer customer, double balance, double currentAmoount){
	Account account = new Account(accountNo,customer,balance);
	}
	public void withdraw(double amount){
		
	}
	
	public double getEligibilityAmount(){
		return 0;
	}
	
}
public class Assignment16 {

	public static void main(String[] args) {
		//Assignment16Account account = new Assignment16Account();
		//Assignment16SavingAccount savingAccount = new Assignment16SavingAccount(101,john,1000);
		

	}

}
