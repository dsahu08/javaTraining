package day2;

public class Assignment8Loan {
	private int loanNo;
	 private int accountNo;
	 private int customerNo;
	 private float loanAmount;
	 private int loanDuration;
	 private float interest;
	 
	 static int loanCounter;
	 
	 public Assignment8Loan()
	 {
		loanCounter++; 
	 }
	 public Assignment8Loan(int accountNo, int customerNo, int loanDuration, float loanAmount, float interest)
	 {
		 loanCounter++;
	 }
	 
	 public float calculateInstallments()
	 {
		 return 0;
	 }
	 
	 public int getAccountNo()
	 {
		 return 0;
	 }
	 
	 public int getCustomerNo()
	 {
		 return 0;
	 }
	 
	 public float getLoanAmount(){
		 return 0;
	 }
	 public float getInterest()
	 {
		 return 0;
	 }
	 public void setAccountNo(int accountNo)
	 {
		 
	 }
	 public void setcustomerNo(int customerNo)
	 {
		 
	 }
	 public void setLoanDuration(int loanDuration)
	 {
		 
	 }
	 public void setLoanAmount(float loanAmount)
	 {
		 
	 }
	 public void setInterest(float interest)
	 {
		 
	 }
	 
	public static void main(String[] args) {
		
		System.out.println("Number of instances:"+loanCounter);
	}

}
