package day1;

class EmployeeGrade{
	int employeeNo;
	String employeeName;
	float customer1Feedback;
	float customer2Feedback;
	float customer3Feedback;
	float averageFeedback;
	char grade;
	
	EmployeeGrade(int employeeNo,
					String employeeName,
					float customer1Feedback,
					float customer2Feedback,
					float customer3Feedback,
					float averageFeedback,
					char grade)
	{
		this.employeeNo = employeeNo;
		this.employeeName = employeeName;
		this.customer1Feedback = customer1Feedback;
		this.customer2Feedback = customer2Feedback;
		this.customer3Feedback = customer3Feedback;
		this.averageFeedback = averageFeedback;
		this.grade = grade;
	}
	
	public EmployeeGrade()
	{
		
	}
	
	public void calculateAverageFeedback()
	{
		
	}
	
	public void calculateGrade()
	{
		
	}
	
	public void displayInfo()
	{
		
	}
}

public class Assignment10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
