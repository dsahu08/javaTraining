package package1;

public class Child1 extends Base{

	public void getValues(){
		System.out.println(getVariable1());
		System.out.println(getVariable2());
		System.out.println(variable3);
		System.out.println(variable4);
	}
}
